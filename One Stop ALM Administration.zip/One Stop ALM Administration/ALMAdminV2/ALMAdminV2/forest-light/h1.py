import tkinter as tk
from tkinter import ttk
import os
from ttkthemes import ThemedTk
from tkinter import messagebox
from pathlib import Path


# Set custom fonts and colors
title_font = ("Berlin Sans FB Demi", 25, "bold")
label_font = ("Segoe Script", 12, "bold")
button_font = ("Arial", 12, "bold")
bg_color = "#f2f2f2"
fg_color = "#333333"
tab_font = ("Segoe Script", 12)
Olabel_font = ("Segoe Script", 8)

root = tk.Tk()
root.title("One Stop ALM Administration")
root.option_add("*tearOff", False)

# style
style = ttk.Style(root)
file_path = Path(__file__).with_name("forest-light.tcl")
# root.tk.call("source", "c:\\Users\\nivetha.m04\\Desktop\\Jira\\Forest-ttk-theme-master\\forest-light.tcl")
root.tk.call("source", file_path)
style.theme_use("forest-light")
style.configure("TNotebook.Tab", padding=[20, 0], font=tab_font)

# frame for the title and dropdown
title_frame = ttk.Frame(root)
title_frame.grid(row=0, column=0, sticky="nsew")

# Title label
title_label = ttk.Label(title_frame, text="One Stop ALM Administration", font=title_font)
title_label.pack(padx=(10,25), pady=20,side="left")
# title_label.grid(row=0, column=0, padx=(5,25), pady=20)

c_frame = ttk.Frame(title_frame)
c_frame.pack(side="right", padx=(100, 2), pady=20)
# c_frame.grid(row=0, column=2, sticky="E", padx=(25, 5))

# Domain and project connection
domain_label = ttk.Label(c_frame, text="Domain:", font=label_font)
domain_label.pack(side="right", pady=10, padx=(10, 1))

domain_dropdown = ttk.Combobox(c_frame, values=["Option 1", "Option 2", "Option 3"], font=Olabel_font, width=20, height=5)
domain_dropdown.current(0)
domain_dropdown.pack(side="right", pady=10, padx=(1, 10),before=domain_label)

project_label = ttk.Label(c_frame, text="Project:", font=label_font)
project_label.pack(side="right", pady=10, padx=(10, 1),before=domain_dropdown)

project_dropdown = ttk.Combobox(c_frame, values=["Option 1", "Option 2", "Option 3"], font=Olabel_font, width=20, height=5)
project_dropdown.pack(side="right", pady=10, padx=(1, 10),before=project_label)

connect_button = ttk.Button(c_frame, text="Connect",style="Accent.TButton")
connect_button.pack(side="right", padx=(20,1), pady=10,before=project_dropdown)


# tab control
tab_control = ttk.Notebook(root)
tab_control.grid(row=1, column=0, columnspan=5, sticky="nsew",rowspan=3)

# tabs
tab1 = ttk.Frame(tab_control)
tab2 = ttk.Frame(tab_control)
tab3 = ttk.Frame(tab_control)
tab4 = ttk.Frame(tab_control)
tab5 = ttk.Frame(tab_control)

tab_control.add(tab1, text="User Access Management")
tab_control.add(tab2, text="  Data Extraction  ")
tab_control.add(tab3, text=" Report Generation ")
tab_control.add(tab4, text="Maintenance Notification")
tab_control.add(tab5, text="Project Usage and Health Status")


# contents to each tab
label1 = ttk.Label(tab1, text="", font=label_font)
label1.pack(padx=10, pady=10)

label2 = ttk.Label(tab2, text="", font=label_font)
label2.pack(padx=10, pady=10)

label3 = ttk.Label(tab3, text="", font=label_font)
label3.pack(padx=10, pady=10)

label4 = ttk.Label(tab4, text="", font=label_font)
label4.pack(padx=10, pady=10)

label5 = ttk.Label(tab5, text="", font=label_font)
label5.pack(padx=10, pady=10)

# weights for responsive layout
root.grid_rowconfigure(1, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
tab_control.grid_rowconfigure(0, weight=1)
tab_control.grid_columnconfigure(0, weight=1)
tab_control.grid_columnconfigure(1, weight=1)
tab_control.grid_columnconfigure(2, weight=2)
tab_control.grid_columnconfigure(3, weight=1)
tab_control.grid_columnconfigure(4, weight=1)


root.mainloop()
