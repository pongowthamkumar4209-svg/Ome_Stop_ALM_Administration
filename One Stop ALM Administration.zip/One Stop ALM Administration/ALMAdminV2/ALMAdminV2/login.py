# from calendar import Calendar
# from calendar import calendar
import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry
from ttkthemes import ThemedTk
from tkinter import messagebox
from win32com.client import Dispatch
from tkinter import PhotoImage, ttk
from bs4 import BeautifulSoup
import openpyxl
from openpyxl import Workbook
import win32com.client
from pathlib import Path
from PIL import Image, ImageTk
from tkinter import *
import win32com.client
from bs4 import BeautifulSoup
import pandas as pd
from docx import Document
from docx.shared import Pt
import os
from datetime import datetime
import re
from PIL import Image, ImageTk
from tkcalendar import Calendar
import time
# from h2 import ALMAdminApp


class ALMQueryProcessor:
    def __init__(self):
        pass

    @staticmethod
    def extract_text_from_html(html):
        if pd.notna(html):
            if html.strip().startswith('<') and html.strip().endswith('>'):
                # If the input looks like HTML, extract text using BeautifulSoup
                soup = BeautifulSoup(html, 'html.parser')
                return soup.get_text()
            else:
                # If the input is plain text, return the original value
                return html
        else:
            return ''

    # @staticmethod
    def execute_query_and_save_to_excel(self,input_excel_file, excel_file, word_file_prefix,tdc):
        # print(tdc)
        input_workbook = openpyxl.load_workbook(input_excel_file)
        input_sheet = input_workbook.active

        ts_test_ids = []
        tester_names = []
        is_header = True
        for row in input_sheet.iter_rows(values_only=True):
            if is_header:
                is_header = False
                continue
            test_id = row[9]
            tester_name = row[4]  # Assuming the test ID is in the first column
            ts_test_ids.append(str(test_id))
            tester_names.append(str(tester_name))

        input_workbook.close()

        self.create_excel_file(excel_file)
        self.populate_excel_file(ts_test_ids, tester_names, excel_file,tdc)
        self.create_word_documents_from_excel(excel_file, word_file_prefix)
        messagebox.showinfo("Success", "Test evidence has been generated")

    # @staticmethod
    def create_excel_file(self,excel_file):
        headers = ["DS_ID", "TS_TEST_ID", "TS_NAME", "TS_DESCRIPTION", "PREREQUISITES",
                "DS_STEP_NAME", "DS_DESCRIPTION", "DS_EXPECTED", "DS_STEP_ORDER",
                "TEST_SCRIPT_STATUS", "Tester name"]

        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.append(headers)

        workbook.save(excel_file)

    # @staticmethod
    def populate_excel_file(self,ts_test_ids, tester_names, excel_file,tdc):
        workbook = openpyxl.load_workbook(excel_file)
        sheet = workbook.active
        qc_connection=tdc
        component_row_count = 2
        i = 0
        for ts_test_id in ts_test_ids:
            initial_row = component_row_count

            current_query = f"Select DESSTEPS.DS_ID, TEST.TS_TEST_ID, TEST.TS_NAME, TEST.TS_DESCRIPTION, TEST.TS_USER_25, DESSTEPS.DS_STEP_NAME, DESSTEPS.DS_DESCRIPTION, DESSTEPS.DS_EXPECTED, DESSTEPS.DS_STEP_ORDER, TEST.TS_USER_05 from TEST, DESSTEPS Where TS_TEST_ID='{ts_test_id}' AND TS_TEST_ID = DS_TEST_ID order by TS_TEST_ID, DS_STEP_ORDER ASC"

            com = qc_connection.Command
            com.CommandText = current_query
            record_set = com.Execute()

            while not record_set.EOR:
                responsible_tester = tester_names[i]
                step_id = record_set.FieldValue(0)
                test_id = record_set.FieldValue(1)
                test_name = record_set.FieldValue(2)
                test_description = ALMQueryProcessor.extract_text_from_html(record_set.FieldValue(3))
                prereq = ALMQueryProcessor.extract_text_from_html(record_set.FieldValue(4))
                step_name = record_set.FieldValue(5)
                step_description = ALMQueryProcessor.extract_text_from_html(record_set.FieldValue(6))
                expected = ALMQueryProcessor.extract_text_from_html(record_set.FieldValue(7))
                step_order = record_set.FieldValue(8)
                ts_user_05 = record_set.FieldValue(9)
                sheet.append([step_id, test_id, test_name, test_description,
                            prereq, step_name, step_description, expected, step_order, ts_user_05, responsible_tester])

                record_set.Next()
                component_row_count += 1
            i += 1
            sheet.merge_cells(f"B{initial_row}:B{component_row_count - 1}")
            sheet.merge_cells(f"C{initial_row}:C{component_row_count - 1}")
            sheet.merge_cells(f"D{initial_row}:D{component_row_count - 1}")
            sheet.merge_cells(f"E{initial_row}:E{component_row_count - 1}")
            sheet.merge_cells(f"J{initial_row}:J{component_row_count - 1}")
            sheet.merge_cells(f"K{initial_row}:K{component_row_count - 1}")

        # qc_connection.Disconnect()
        # qc_connection.Logout()
        # qc_connection.ReleaseConnection()

        workbook.save(excel_file)

    @staticmethod
    def create_word_documents_from_excel(excel_file, word_file_prefix):
        workbook = openpyxl.load_workbook(excel_file)
        sheet = workbook.active

        row_min = 2
        while row_min < sheet.max_row:
            test_script_name = sheet.cell(row=row_min, column=3).value
            responsible_tester = sheet.cell(row=row_min, column=11).value
            ts_id = sheet.cell(row=row_min, column=2).value

            tester_folder = os.path.join(word_file_prefix, responsible_tester)
            if not os.path.exists(tester_folder):
                os.makedirs(tester_folder)

            doc = Document()
            heading_style = doc.styles['Heading 1']
            heading_style.font.size = Pt(14)
            heading_style.font.bold = True
            body_style = doc.styles['Normal']
            body_style.font.size = Pt(12)

            test_description = sheet.cell(row=row_min, column=4).value
            pre_condition = sheet.cell(row=row_min, column=5).value

            doc.add_paragraph().add_run("Test Name: ").bold = True
            doc.add_paragraph().add_run(test_script_name).bold = False
            doc.add_paragraph().add_run("Test Description: ").bold = True
            doc.add_paragraph().add_run(test_description).bold = False
            doc.add_paragraph().add_run("PreCondition: ").bold = True
            doc.add_paragraph().add_run(pre_condition).bold = False
            doc.add_paragraph().add_run("Step Details: ").bold = True

            table = doc.add_table(rows=1, cols=3)
            table.style = 'Table Grid'
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = 'Step Name'
            hdr_cells[1].text = 'Step Description'
            hdr_cells[2].text = 'Expected Result'

            num_steps = 0
            step_row = row_min + 1
            while step_row <= sheet.max_row:
                if sheet.cell(row=step_row, column=3).value is not None:
                    break
                num_steps += 1
                step_row += 1

            step_row = row_min
            for _ in range(num_steps + 1):
                step_name = sheet.cell(row=step_row, column=6).value
                step_description = sheet.cell(row=step_row, column=7).value
                expected_result = sheet.cell(row=step_row, column=8).value
                row_cells = table.add_row().cells
                row_cells[0].text = step_name if step_name is not None else ""
                row_cells[1].text = step_description if step_description is not None else ""
                row_cells[2].text = expected_result if expected_result is not None else ""

                step_row += 1

            doc.add_page_break()
            current_word_file = os.path.join(tester_folder, f"{ts_id}_{test_script_name[:50]}.docx")
            doc.save(current_word_file)
            row_min = step_row

class TestTypeUpdator:

    def __init__(self):
        pass

    def convert_to_manual(self,test_case_ids, test_type, qc_connection):
        com = qc_connection.Command

        for test_case_id in test_case_ids:
            com.CommandText = f"UPDATE TEST SET TS_TYPE = '{test_type}' WHERE TS_TEST_ID = '{test_case_id}'"
            recset = com.Execute()
            print(recset)

        print("Update Complete")

    def execute_conversion(self,test_case_ids, test_type,tdc):
        qc_connection=tdc
        # Execute conversion
        self.convert_to_manual(test_case_ids, test_type, qc_connection)

        # # Disconnect from ALM
        # qc_connection.Disconnect()
        # qc_connection.Logout()
        # qc_connection.ReleaseConnection()

        messagebox.showinfo("Conversion Complete", "Test cases have been converted successfully.") 

class DefectExtractor:
    def __init__(self):
        pass  
    
    def convert_to_date(self,value):
        if pd.notna(value):
            # Parse the string into a datetime object
            date_obj = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
            # Format the datetime object as required
            return date_obj.strftime('%d/%m/%Y')
        else:
            return ''
        
    def extract_text_from_html(self,html):
        if pd.notna(html):
            if html.strip().startswith('<') and html.strip().endswith('>'):
                # If the input looks like HTML, extract text using BeautifulSoup
                soup = BeautifulSoup(html, 'html.parser')
                return soup.get_text()
            else:
                # If the input is plain text, return the original value
                return html
        else:
            return ''
    def sanitize_text(self,text):
        """
        Sanitize text by removing or replacing illegal characters.
        """
        if text is None:
            return None
        
        # Define a regular expression pattern to match illegal characters
        illegal_chars_pattern = re.compile(r'[\\/:*?"<>|]')  # Add more characters if needed
        
        # Replace illegal characters with an empty string
        sanitized_text = re.sub(illegal_chars_pattern, '', text)
        
        return sanitized_text

    def Defect_Extraction(self,status_list, priority_list, severity_list, category_list,tdc):

        headers = ["Bug ID","Bug Status","Bug Category","Test Execution Release","Test Execution Cycle","Detected Environment","Bug Summary","Bug Description","Bug Comments","Bug Severity","Bug Priority","Bug Detected By","Bug Detected Date","Bug Closing date"]

        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.append(headers)

        qc_connection=tdc

        if status_list:
            where_clause = " OR ".join([f"BUG.BG_STATUS='{status}'" for status in status_list])
            sql_query = f"SELECT BUG.BG_BUG_ID,BUG.BG_STATUS,BUG.BG_USER_01,BUG.BG_DETECTED_IN_REL,BUG.BG_DETECTED_IN_RCYC,BUG.BG_ENVIRONMENT,BUG.BG_SUMMARY,BUG.BG_DESCRIPTION,BUG.BG_DEV_COMMENTS,BUG.BG_SEVERITY,BUG.BG_PRIORITY,BUG.BG_DETECTED_BY,BUG.BG_DETECTION_DATE,BUG.BG_CLOSING_DATE FROM BUG WHERE {where_clause} order by BUG.BG_BUG_ID"
        elif priority_list: 
            where_clause = " OR ".join([f"BUG.BG_PRIORITY='{priority}'" for priority in priority_list])
            sql_query = f"SELECT BUG.BG_BUG_ID,BUG.BG_STATUS,BUG.BG_USER_01,BUG.BG_DETECTED_IN_REL,BUG.BG_DETECTED_IN_RCYC,BUG.BG_ENVIRONMENT,BUG.BG_SUMMARY,BUG.BG_DESCRIPTION,BUG.BG_DEV_COMMENTS,BUG.BG_SEVERITY,BUG.BG_PRIORITY,BUG.BG_DETECTED_BY,BUG.BG_DETECTION_DATE,BUG.BG_CLOSING_DATE FROM BUG WHERE {where_clause} order by BUG.BG_BUG_ID"    
        elif severity_list: 
            where_clause = " OR ".join([f"BUG.BG_SEVERITY='{severity}'" for severity in severity_list])
            sql_query = f"SELECT BUG.BG_BUG_ID,BUG.BG_STATUS,BUG.BG_USER_01,BUG.BG_DETECTED_IN_REL,BUG.BG_DETECTED_IN_RCYC,BUG.BG_ENVIRONMENT,BUG.BG_SUMMARY,BUG.BG_DESCRIPTION,BUG.BG_DEV_COMMENTS,BUG.BG_SEVERITY,BUG.BG_PRIORITY,BUG.BG_DETECTED_BY,BUG.BG_DETECTION_DATE,BUG.BG_CLOSING_DATE FROM BUG WHERE {where_clause} order by BUG.BG_BUG_ID" 
        elif category_list: 
            where_clause = " OR ".join([f"BUG.BG_USER_01='{category}'" for category in category_list])
            sql_query = f"SELECT BUG.BG_BUG_ID,BUG.BG_STATUS,BUG.BG_USER_01,BUG.BG_DETECTED_IN_REL,BUG.BG_DETECTED_IN_RCYC,BUG.BG_ENVIRONMENT,BUG.BG_SUMMARY,BUG.BG_DESCRIPTION,BUG.BG_DEV_COMMENTS,BUG.BG_SEVERITY,BUG.BG_PRIORITY,BUG.BG_DETECTED_BY,BUG.BG_DETECTION_DATE,BUG.BG_CLOSING_DATE FROM BUG WHERE {where_clause} order by BUG.BG_BUG_ID" 
        else:
            sql_query=f"SELECT BUG.BG_BUG_ID,BUG.BG_STATUS,BUG.BG_USER_01,BUG.BG_DETECTED_IN_REL,BUG.BG_DETECTED_IN_RCYC,BUG.BG_ENVIRONMENT,BUG.BG_SUMMARY,BUG.BG_DESCRIPTION,BUG.BG_DEV_COMMENTS,BUG.BG_SEVERITY,BUG.BG_PRIORITY,BUG.BG_DETECTED_BY,BUG.BG_DETECTION_DATE,BUG.BG_CLOSING_DATE FROM BUG order by BUG.BG_BUG_ID"

        command = qc_connection.Command
        command.CommandText = sql_query
        record_set = command.Execute()
        records_found = False
        while not record_set.EOR:
            records_found = True
            Bug_ID = record_set.FieldValue(0)
            Bug_Status = record_set.FieldValue(1)
            Bug_Category = record_set.FieldValue(2)
            Test_Execution_Release = record_set.FieldValue(3)
            Test_Execution_Cycle = record_set.FieldValue(4)
            Detected_Environment = record_set.FieldValue(5)
            Bug_Summary = self.extract_text_from_html(record_set.FieldValue(6))
            Bug_Description = self.extract_text_from_html(record_set.FieldValue(7))
            Bug_Comments = self.extract_text_from_html(record_set.FieldValue(8))
            Bug_Severity = record_set.FieldValue(9)
            Bug_Priority = record_set.FieldValue(10)
            Bug_Detected_By = record_set.FieldValue(11)
            Bug_Detected_Date = self.convert_to_date(record_set.FieldValue(12))
            Bug_Closing_date = self.convert_to_date(record_set.FieldValue(13))
            
            summary = self.sanitize_text(Bug_Summary)
            description = self.sanitize_text(Bug_Description)
            comment = self.sanitize_text(Bug_Comments)
            environment = self.sanitize_text(Detected_Environment)
            sheet.append([Bug_ID, Bug_Status, Bug_Category, Test_Execution_Release,
                Test_Execution_Cycle,environment,summary, description, comment, Bug_Severity, Bug_Priority, Bug_Detected_By,
                Bug_Detected_Date,Bug_Closing_date])

            record_set.Next()
        workbook.save("ExtractedDefects.xlsx")
        print("Success")      

class testCaseExtractor_WA():
    def __init__(self):
        pass 

    def download_test_files_and_attachments(self,test, foldername):
        Download_Path = ""
        test_attach_fact = test.Attachments
        attach_list = test_attach_fact.NewList("")
        current_directory = os.path.abspath(os.getcwd())
        # print("Current Directory:", current_directory)

        for t_attach in attach_list:
            ALM_ID = test.Field("TS_TEST_ID")
            attachment_folder = os.path.join(current_directory, "ALMExtraction", str(ALM_ID), "Attachments")

            # Check if the directory exists, if not, create it
            if not os.path.exists(attachment_folder):
                os.makedirs(attachment_folder)

            test_attach_storage = t_attach.AttachmentStorage
            test_attach_storage.ClientPath = attachment_folder

            try:
                t_attach.Load(True, test_attach_storage.ClientPath)
                # print(f"Downloaded attachment: {t_attach.FileName}")
                Download_Path = Download_Path + ";" + t_attach.FileName
            except Exception as e:
                print(f"Error downloading attachment: {t_attach.FileName}")
                #  print(str(e))

        return Download_Path

    # This function is to download the attachments at test step level
    def download_test_step_attachments(self,test_step, test, foldername):
        Download_Path = ""
        test_attach_fact = test_step.Attachments
        attach_list = test_attach_fact.NewList("")

        current_directory = os.path.abspath(os.getcwd())
        # print("Current Directory:", current_directory)

        for t_attach in attach_list:
            # current_direct = os.path.dirname(os.path.abspath(__file__))
            ALM_ID = test.Field("TS_TEST_ID")

            attachment_folder = os.path.join(current_directory, "ALMExtraction", test_step.StepName, str(ALM_ID), "Attachments")
            if not os.path.exists(attachment_folder):
                os.makedirs(attachment_folder)
            test_attach_storage = t_attach.AttachmentStorage
            test_attach_storage.ClientPath = attachment_folder
            # test_attach_storage = t_attach.AttachmentStorage
            # test_attach_storage.ClientPath = os.path.join(current_direct, "ALMExtract", test_step.StepName, str(ALM_ID), "Attachments")

            t_attach.Load(True, test_attach_storage.ClientPath)

            # print("\nAfter download")
            # print("Download path:", test_attach_storage.ClientPath)
            # print("The filename:", t_attach.FileName)
            Download_Path = Download_Path + ";" + t_attach.FileName

        return Download_Path    
    
    def GetNodesList(self,tdc,RootNode):
        arrStrNodesList = [RootNode]
        objTreeManager = tdc.TreeManager
        objSubjectNode = objTreeManager.NodeByPath(RootNode)
        for i in range(1, objSubjectNode.Count + 1):
            if objSubjectNode.Child(i).Count >= 1:
                arrStrTempNodeList = self.GetNodesList(tdc, objSubjectNode.Child(i).Path)
                arrStrNodesList.extend(arrStrTempNodeList)
            else:
                arrStrNodesList.append(objSubjectNode.Child(i).path)
        return arrStrNodesList
    
    def TestCase_WA(self,folder_path,tdc):
        # folder_path = "Subject\\In_Essence_Bank"
        wb = openpyxl.Workbook()
        ws = wb.active

        # Header row
        headers = [
            "Test ID",
            "Test Name",
            "TC Attachment Path",
            "Test Description",
            "Test Type",
            "Test Author",
            "Creation Date",
            "Comments",
            "Change Status",
            "Execution Status",
            "Subject",
            "Path",
            "Tree Path",
            "Step Name",
            "Step Description",
            "Expected Result",
            "Test Step Attachment Path"
        ]
        for col_num, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_num, value=header)

        folderNameLists = self.GetNodesList(tdc, folder_path)
        i = 2
        for foldername in folderNameLists:
            test_case_tree_manager = tdc.TreeManager
            test_case_folder = test_case_tree_manager.NodeByPath(foldername)
            test_case_factory = test_case_folder.TestFactory
            test_case_list = test_case_factory.NewList("")
            
            for test in test_case_list:
                iRowCountBefore = i
                iColumn = 0
                if test.Attachments.NewList(""):
                    download_Path = self.download_test_files_and_attachments(test, foldername)
                else:
                    download_Path = "No Attachment for this"

                iColumn = self.populate_test_data(test, ws[i], foldername, download_Path)
                
                # for teststeps inside each test case
                test_steps = test.DesignStepFactory.NewList("")
                for test_step in test_steps:
                    if test_step.Attachments.NewList(""):
                        Attach_Path = self.download_test_step_attachments(test_step, test, foldername)
                    else:
                        Attach_Path = "No Attachment for this"
                    
                    self.populate_test_step_data(test_step, ws[i], iColumn, Attach_Path)                

                    i += 1

        # Save the Excel file
        wb.save("TestCaseDetailsFinal_WA.xlsx")
        # tdc.Logout()
        # tdc.Disconnect()
        # app.root.destroy()

        # Display success message
        messagebox.showinfo("Success", "Attachments downloaded successfully.")

    def populate_test_data(self,test, row, foldername, download_Path):
        row[0].value = test.Field("TS_TEST_ID")
        row[1].value = test.Field("TS_NAME").strip()
        row[2].value = download_Path
        row[3].value = self.extract_text_from_html(test.Field("TS_DESCRIPTION"))
        row[4].value = test.Field("TS_TYPE").strip()
        row[5].value = test.Field("TS_RESPONSIBLE").strip()
        creation_date = test.Field("TS_CREATION_DATE")
        if creation_date:
            creation_date_str = creation_date.strftime('%Y-%m-%d %H:%M:%S')
        else:
            creation_date_str = ""
        row[6].value = creation_date_str
        # row[7].value = test.Field("TS_DEV_COMMENTS")
        row[7].value = self.extract_text_from_html(test.Field("TS_DEV_COMMENTS"))
        row[8].value = test.Field("TS_BPTA_CHANGE_DETECTED")
        row[9].value = test.Field("TS_EXEC_STATUS").strip()
        row[10].value = str(test.Field("TS_SUBJECT"))
        row[11].value = foldername.strip()
        row[12].value = test.Field("TS_TREE_PATH")
        return 13

    # Function to convert Html to text
    def extract_text_from_html(self,html):
        if html is not None:
            soup = BeautifulSoup(html, "html.parser")
            return soup.get_text()
        else:
            return ""

    # printing test step data
    def populate_test_step_data(self,test_step, row, step_column, Attach_Path):
        row[step_column].value = test_step.Field("DS_STEP_NAME")
        step_description = self.extract_text_from_html(test_step.Field("DS_DESCRIPTION"))
        expected_result = self.extract_text_from_html(test_step.Field("DS_EXPECTED"))
        row[step_column + 1].value = step_description
        row[step_column + 2].value = expected_result
        row[step_column + 3].value = Attach_Path

    # # when closing User Interface it will disconnect the connection
    # def on_closing():
    #     # Disconnect and release the connection
    #     app.tdc.Logout()
    #     app.tdc.Disconnect()
    #     app.root.destroy() 

class testCaseExtractor():
    def __init__(self):
        pass 
  
    
    def GetNodesList(self,tdc,RootNode):
        arrStrNodesList = [RootNode]
        objTreeManager = tdc.TreeManager
        objSubjectNode = objTreeManager.NodeByPath(RootNode)
        for i in range(1, objSubjectNode.Count + 1):
            if objSubjectNode.Child(i).Count >= 1:
                arrStrTempNodeList = self.GetNodesList(tdc, objSubjectNode.Child(i).Path)
                arrStrNodesList.extend(arrStrTempNodeList)
            else:
                arrStrNodesList.append(objSubjectNode.Child(i).path)
        return arrStrNodesList
    
    def TestCase_WA(self, folder_path, tdc):
        wb = openpyxl.Workbook()
        ws = wb.active

        # Header row
        headers = [
            "Test ID",
            "Test Name",
            "Test Description",
            "Test Type",
            "Test Author",
            "Creation Date",
            "Comments",
            "Change Status",
            "Execution Status",
            "Subject",
            "Path",
            "Tree Path",
            "Requirement ID",
            "Requirement Name",
            "Step Name",
            "Step Description",
            "Expected Result"
        ]
        for col_num, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_num, value=header)

        folderNameLists = self.GetNodesList(tdc, folder_path)
        i = 2
        for foldername in folderNameLists:
            test_case_tree_manager = tdc.TreeManager
            test_case_folder = test_case_tree_manager.NodeByPath(foldername)
            test_case_factory = test_case_folder.TestFactory
            test_case_list = test_case_factory.NewList("")

            for test in test_case_list:
                iRowCountBefore = i
                iColumn = 0
                iColumn = self.populate_test_data(test, ws[i], foldername)
                
                # Writing requirement details
                covered_reqs_list = test.GetCoverList()
                for req in covered_reqs_list:
                    req_id = req.ID
                    req_name = req.Name

                    # Add requirement details in subsequent columns
                    ws.cell(row=i, column=iColumn+1, value=req_id)
                    ws.cell(row=i, column=iColumn + 2, value=req_name.strip())
                    i += 1
                
                # Start test steps from column 15
                step_column_start = 15
                test_steps = test.DesignStepFactory.NewList("")
                for test_step in test_steps:
                    self.populate_test_step_data(test_step, ws, i, step_column_start)
                    i += 1

        # Save the Excel file
        wb.save("TestCaseDetailsFinal.xlsx")

        # Display success message
        messagebox.showinfo("Success", "Test cases and steps downloaded successfully.")    

    def populate_test_data(self,test, row, foldername):
        row[0].value = test.Field("TS_TEST_ID")
        row[1].value = test.Field("TS_NAME").strip()
        # row[2].value = download_Path
        row[2].value = self.extract_text_from_html(test.Field("TS_DESCRIPTION"))
        row[3].value = test.Field("TS_TYPE").strip()
        row[4].value = test.Field("TS_RESPONSIBLE").strip()
        creation_date = test.Field("TS_CREATION_DATE")
        if creation_date:
            creation_date_str = creation_date.strftime('%Y-%m-%d %H:%M:%S')
        else:
            creation_date_str = ""
        row[5].value = creation_date_str
        # row[7].value = test.Field("TS_DEV_COMMENTS")
        row[6].value = self.extract_text_from_html(test.Field("TS_DEV_COMMENTS"))
        row[7].value = test.Field("TS_BPTA_CHANGE_DETECTED")
        row[8].value = test.Field("TS_EXEC_STATUS").strip()
        row[9].value = str(test.Field("TS_SUBJECT"))
        row[10].value = foldername.strip()
        row[11].value = test.Field("TS_TREE_PATH")
        
        return 12

    # Function to convert Html to text
    def extract_text_from_html(self,html):
        if html is not None:
            soup = BeautifulSoup(html, "html.parser")
            return soup.get_text()
        else:
            return ""

    # printing test step data
    # def populate_test_step_data(self,test_step, row, step_column):
    #     row[step_column].value = test_step.Field("DS_STEP_NAME")
    #     step_description = self.extract_text_from_html(test_step.Field("DS_DESCRIPTION"))
    #     expected_result = self.extract_text_from_html(test_step.Field("DS_EXPECTED"))
    #     row[step_column + 1].value = step_description
    #     row[step_column + 2].value = expected_result
    def populate_test_step_data(self, test_step, ws, row_num, step_column_start):
        # Safely extract fields and handle None values
        step_name = test_step.Field("DS_STEP_NAME")
        step_description = test_step.Field("DS_DESCRIPTION")
        expected_result = test_step.Field("DS_EXPECTED")

        # Use .strip() only if the field is not None
        step_name = step_name.strip() if step_name else ""
        step_description = self.extract_text_from_html(step_description) if step_description else ""
        expected_result = self.extract_text_from_html(expected_result) if expected_result else ""

        # Access cells directly by row and column number
        ws.cell(row=row_num, column=step_column_start, value=step_name)
        ws.cell(row=row_num, column=step_column_start + 1, value=step_description)
        ws.cell(row=row_num, column=step_column_start + 2, value=expected_result)




class Attachment_Downloader():
    def __init__(self):
        pass 
    def download_Attachments(self,test_set_ids,tdc):
        suite_ids_list = [s.strip() for s in test_set_ids.split(",")]
        for Suite_ID in suite_ids_list:
            print(Suite_ID)
            test_set_id=Suite_ID 
            test_suite_factory = tdc.TestSetFactory
            test_suite = test_suite_factory.Item(test_set_id)
            test_instance_fact=test_suite.TSTestFactory
            test_instance_list=test_instance_fact.NewList("")
            
            wb = Workbook()
            ws = wb.active
            

            # Adding headers to the Excel sheet
            headers = ["Test Set ID", "Test Instance ID","Test Case ID","Test case type", "Latest Test Run ID","Run status","tester XT ID","Tester full name","Execution date", "Attachment validation-Run Level","Download path - Run Level","Step Name","Status","Attachment validation-Step Level","Download Path"]
            ws.append(headers)
            ws.cell(row=2, column=1).value = test_set_id
            
            row=2
            for test_instance in test_instance_list:
                id=test_instance.id
                testCase_Id=test_instance.testId
                print(id)
                type=test_instance.type
                # TestId:
                # '101'
                ws.cell(row=row, column=2).value = id
                ws.cell(row=row, column=3).value = testCase_Id
                ws.cell(row=row, column=4).value = type
                # User_full_name=test_instance.Field("TC_USER_TEMPLATE_03")  218, 247, 248
                tester_xt_id=test_instance.Field("TC_ACTUAL_TESTER")
                
                # print(test_instance.Name)
                Run_Factory=test_instance.RunFactory
                runs=Run_Factory.NewList("")
                latest_run = None
                latest_date = None
                latest_time = None
                for run in runs:
                    run_date = run.Field("RN_EXECUTION_DATE")
                    run_time = run.Field("RN_EXECUTION_TIME")
                    if (latest_date is None or run_date > latest_date or
                    (run_date == latest_date and run_time > latest_time)):
                        latest_run = run
                        latest_date = run_date
                        latest_time = run_time
                if not latest_run:
                    # print("No runs found for this test instance.")
                    ws.cell(row=row, column=5).value = "No runs found"
                    ws.cell(row=row, column=6).value = ""  # Clear the attachment status columns
                    ws.cell(row=row, column=9).value = ""
                    row=row
                if latest_run:
                    # print ("Latest Run ID for",test_instance.Name,":", latest_run.ID)
                    ws.cell(row=row, column=5).value = latest_run.ID
                    Run_Attachment_Fact=latest_run.Attachments
                    Run_attachments=Run_Attachment_Fact.NewList("")
                    ws.cell(row=row, column=6).value = latest_run.Status
                    # User_full_name=test_instance.Field("TC_USER_TEMPLATE_03")
                    # ws.cell(row=row , column=6).value = User_full_name
                    Download_Path_R=" "
                    if len(Run_attachments) > 0:
                            # print(latest_run.ID,": Yes having attachment")
                            ws.cell(row=row, column=10).value = "Having Attachment"
                            for R_attach in Run_attachments:
                                run_id=latest_run.ID
                                # step_name=step.Name
                                current_ddirectory = os.path.abspath(os.getcwd())
                                attachment_ffolder = os.path.join(current_ddirectory, "ALMExtraction",test_set_id, str(run_id))
                                testR_attach_storage = R_attach.AttachmentStorage
                                testR_attach_storage.ClientPath = attachment_ffolder
                                try:
                                    R_attach.Load(True, testR_attach_storage.ClientPath)
                                    # print(f"Downloaded attachment: {t_attach.FileName}")
                                    Download_Path_R = Download_Path_R + ";" + R_attach.FileName
                                except Exception as e:
                                    print(f"Error downloading attachment: {t_attach.FileName}")                                
                            ws.cell(row=row, column=11).value = Download_Path_R       
                    else:
                            # print(latest_run.ID,":Not having attachment")
                            ws.cell(row=row, column=10).value = "No Attachments"
                    design_steps_factory = latest_run.StepFactory
                    design_steps = design_steps_factory.NewList("")
                    
                    exec_user = latest_run.Field("RN_TESTER_NAME")
                    exec_date = latest_run.Field("RN_EXECUTION_DATE")
                    ws.cell(row=row, column=7).value = tester_xt_id
                    day = exec_date.day
                    month = exec_date.month
                    year = exec_date.year

                # Format date as DD/MM/YYYY
                    formatted_date = f"{day:02d}/{month:02d}/{year}"

                # Set formatted date in column 9
                    ws.cell(row=row, column=9).value = formatted_date
                    steprow=row
                    for step in design_steps:
                        # print(step.Name)
                        ws.cell(row=steprow, column=12).value = step.Name
                        ws.cell(row=steprow, column=13).value = step.Status
                        attachment_factory = step.Attachments
                        attachments = attachment_factory.NewList("")
                        Download_Path=""
                        if len(attachments) > 0:
                            # print("Yes having attachment")
                            ws.cell(row=steprow, column=14).value = "Having Attachment"
                            # download_Path = download_test_files_and_attachments(attachments)
                            for t_attach in attachments:
                                run_id=latest_run.ID
                                step_name=step.Name
                                current_directory = os.path.abspath(os.getcwd())
                                attachment_folder = os.path.join(current_directory, "ALMExtraction",test_set_id, str(run_id), step_name)
                                test_attach_storage = t_attach.AttachmentStorage
                                test_attach_storage.ClientPath = attachment_folder
                                try:
                                    t_attach.Load(True, test_attach_storage.ClientPath)
                                    # print(f"Downloaded attachment: {t_attach.FileName}")
                                    Download_Path = Download_Path + ";" + t_attach.FileName
                                except Exception as e:
                                    print(f"Error downloading attachment: {t_attach.FileName}")                                
                            ws.cell(row=steprow, column=15).value = Download_Path
                        else:
                            # print("Not having attachment")
                            ws.cell(row=steprow, column=14).value = "No Attachments"
                        steprow=steprow+1
            # Access other run properties as needed
                else:
                    # print("No runs found for this test instance.")
                    steprow=row+1
                row=steprow
            
            now = datetime.now()
            formatted_date = now.strftime("%d-%m-%Y_%H-%M-%S")    
            filename=f"{test_set_id}_{formatted_date}.xlsx"
            wb.save(filename)  
        print("Attachments downloaded successfully")

    def download_Attachments_All(self,tdc):
        qc_connection=tdc
        testFact=qc_connection.TestSetFactory
        testSets=testFact.NewList("")
        for testset in testSets:
            
            wb = Workbook()
            ws = wb.active  
            test_set_id=testset.ID     

            # Adding headers to the Excel sheet
            headers = ["Test Set ID", "Test Instance ID","Test Case ID","Test case type", "Latest Test Run ID","Run status","tester XT ID","Tester full name","Execution date", "Attachment validation-Run Level","Download path - Run Level","Step Name","Status","Attachment validation-Step Level","Download Path"]
            ws.append(headers)
            ws.cell(row=2, column=1).value = test_set_id
            # print(testset.ID)
            testInstancefact=testset.TSTestFactory
            test_instance_list=testInstancefact.NewList("")
            row=2
            for test_instance in test_instance_list:
                id=test_instance.id
                testCase_Id=test_instance.testId
                # print(id)
                type=test_instance.type

                ws.cell(row=row, column=2).value = id
                ws.cell(row=row, column=3).value = testCase_Id
                ws.cell(row=row, column=4).value = type
                tester_xt_id=test_instance.Field("TC_ACTUAL_TESTER")

                Run_Factory=test_instance.RunFactory
                runs=Run_Factory.NewList("")
                # print("HI")
                latest_run = None
                latest_date = None
                latest_time = None
                for run in runs:
                    run_date = run.Field("RN_EXECUTION_DATE")
                    run_time = run.Field("RN_EXECUTION_TIME")
                    if (latest_date is None or run_date > latest_date or
                    (run_date == latest_date and run_time > latest_time)):
                        latest_run = run
                        latest_date = run_date
                        latest_time = run_time

                if not latest_run:
                    ws.cell(row=row, column=5).value = "No runs found"
                    ws.cell(row=row, column=6).value = ""  # Clear the attachment status columns
                    ws.cell(row=row, column=9).value = ""
                    row=row
                if latest_run:
                    latestRunId=latest_run.ID
                    ws.cell(row=row, column=5).value = latest_run.ID
                    # print(f"The latest run id is {latestRunId} for test instance {id} under testset {testset.ID}")
                    Run_Attachment_Fact=latest_run.Attachments
                    Run_attachments=Run_Attachment_Fact.NewList("")
                    ws.cell(row=row, column=6).value = latest_run.Status
                    Download_Path_R=" "

                    if len(Run_attachments) > 0:
                        ws.cell(row=row, column=10).value = "Having Attachment"
                        for R_attach in Run_attachments:
                            
                            run_id=latest_run.ID
                            current_ddirectory = os.path.abspath(os.getcwd())
                            attachment_ffolder = os.path.join(current_ddirectory, "ALMExtraction",str(test_set_id), str(run_id))
                            # # step_name=step.Name
                            # current_ddirectory = os.path.abspath(os.getcwd())
                            # attachment_ffolder = os.path.join(current_ddirectory,str(run_id))
                            testR_attach_storage = R_attach.AttachmentStorage
                            testR_attach_storage.ClientPath = attachment_ffolder
                            try:
                                R_attach.Load(True, testR_attach_storage.ClientPath)
                                # print(f"Downloaded attachment: {t_attach.FileName}")
                                Download_Path_R = Download_Path_R + ";" + R_attach.FileName
                                print("Attachments downloaded successfully")

                            except:
                                print(f"Error downloading attachment: {R_attach.FileName}")   
                        ws.cell(row=row, column=11).value = Download_Path_R                        

                    else:
                                # print(latest_run.ID,":Not having attachment")
                        ws.cell(row=row, column=10).value = "No Attachments"

                    design_steps_factory = latest_run.StepFactory
                    design_steps = design_steps_factory.NewList("")
                    
                    exec_user = latest_run.Field("RN_TESTER_NAME")
                    exec_date = latest_run.Field("RN_EXECUTION_DATE")
                    ws.cell(row=row, column=7).value = tester_xt_id
                    day = exec_date.day
                    month = exec_date.month
                    year = exec_date.year

                # Format date as DD/MM/YYYY
                    formatted_date = f"{day:02d}/{month:02d}/{year}"

                # Set formatted date in column 9
                    ws.cell(row=row, column=9).value = formatted_date
                    steprow=row
                    for step in design_steps:
                        ws.cell(row=steprow, column=12).value = step.Name
                        ws.cell(row=steprow, column=13).value = step.Status
                        attachment_factory = step.Attachments
                        attachments = attachment_factory.NewList("")
                        Download_Path=""
                        if len(attachments) > 0:
                            # print("Yes having attachment")
                            ws.cell(row=steprow, column=14).value = "Having Attachment"
                            # download_Path = download_test_files_and_attachments(attachments)
                            for t_attach in attachments:
                                run_id=latest_run.ID
                                step_name=step.Name
                                current_directory = os.path.abspath(os.getcwd())
                                attachment_folder = os.path.join(current_directory, "ALMExtraction",str(test_set_id), str(run_id), step_name)
                                test_attach_storage = t_attach.AttachmentStorage
                                test_attach_storage.ClientPath = attachment_folder
                                try:
                                    t_attach.Load(True, test_attach_storage.ClientPath)
                                    # print(f"Downloaded attachment: {t_attach.FileName}")
                                    Download_Path = Download_Path + ";" + t_attach.FileName
                                except Exception as e:
                                    print(f"Error downloading attachment: {t_attach.FileName}")                                
                            ws.cell(row=steprow, column=15).value = Download_Path
                        else:
                            # print("Not having attachment")
                            ws.cell(row=steprow, column=14).value = "No Attachments"
                        steprow=steprow+1
            # Access other run properties as needed
                else:
                    # print("No runs found for this test instance.")
                    steprow=row+1
                row=steprow
            
            now = datetime.now()
            formatted_date = now.strftime("%d-%m-%Y_%H-%M-%S")    
            filename=f"{test_set_id}_{formatted_date}.xlsx"
            wb.save(filename)        
class testCaseExtractor_TS():
    def __init__(self):
        pass

    def download_test_cases(self,test_set_ids,OTA):

            wb=openpyxl.Workbook()
            ws=wb.active

            headers = [
                    "Test Set ID",
                    "testSetName",
                    "Test Case ID",
                    "Test Name",
                    "Test Description",
                    "Criticality",
                    "Test Script Status",
                    "Test Type",
                    "Test Author",
                    "Creation Date",
                    "Comments",
                    "Change Status",
                    "Execution Status",
                    "Step Name",
                    "Step Description",
                    "Expected Result"
            ]
            for col_num, header in enumerate(headers, 1):
                ws.cell(row=1, column=col_num, value=header)

            # Get the resource factory
            tsFact=OTA.TestSetFactory
            testSetIds=test_set_ids
            testSetids=testSetIds.split(',')
            row=2
            for testSetId in testSetids:
                    
                    testSet=tsFact.Item(testSetId)
                    testSetName=testSet.Name
                    tests=testSet.TSTestFactory.NewList("")
                    ws.cell(row=row, column=1).value = testSetId
                    ws.cell(row=row, column=2).value = testSetName
                    
                    for test in tests:
                            
                            print(test.Name)
                            # ws.cell(row=row, column=2).value = test.Name
                            testPlan=test.Test
                            type=test.Type
                            if type=="BUSINESS-PROCESS":
                                    continue
                            elif type=="MANUAL":
                                
                                    test_ID = test.TestId
                                    test_name = test.Field("TS_NAME").strip()
                                    criticality = test.Field("TS_USER_10").strip()
                                    status = test.Field("TS_USER_05").strip()
                                    # row[2].value = download_Path
                                    description = self.extract_text_from_html(test.Field("TS_DESCRIPTION"))
                                    test_type = test.Field("TS_TYPE").strip()
                                    responsible_tester = test.Field("TS_RESPONSIBLE").strip()
                                    creation_date = test.Field("TS_CREATION_DATE")
                                    if creation_date:
                                            creation_date_str = creation_date.strftime('%Y-%m-%d %H:%M:%S')
                                    else:
                                            creation_date_str = ""
                                    crea_date = creation_date_str
                                    # row[7].value = test.Field("TS_DEV_COMMENTS")
                                    comments = self.extract_text_from_html(test.Field("TS_DEV_COMMENTS"))
                                    Change_status = test.Field("TS_BPTA_CHANGE_DETECTED")
                                    exec_status = test.Field("TS_EXEC_STATUS").strip()
                                    subject = str(test.Field("TS_SUBJECT"))
                                    # tree_path = test.Field("TS_TREE_PATH")
                                    ws.cell(row=row, column=3).value = test_ID
                                    ws.cell(row=row, column=4).value= test_name
                                    ws.cell(row=row, column=5).value = description
                                    ws.cell(row=row, column=6).value = criticality
                                    ws.cell(row=row, column=7).value = status
                                    ws.cell(row=row, column=8).value = test_type
                                    ws.cell(row=row, column=9).value = responsible_tester
                                    ws.cell(row=row, column=10).value = crea_date
                                    ws.cell(row=row, column=11).value = comments
                                    ws.cell(row=row, column=12).value = Change_status
                                    ws.cell(row=row, column=13).value = exec_status
                                    #ws.cell(row=row, column=14).value = subject
                                    # ws.cell(row=row, column=11).value = tree_path
                                    # return 12
                                    DesignSteps=testPlan.DesignStepfactory.NewList("")
                                    for step in DesignSteps:
                                            mname=step.StepName
                                            mstepDescription=self.extract_text_from_html(step.StepDescription)
                                            mexpectedResult=self.extract_text_from_html(step.StepExpectedResult)
                                            ws.cell(row=row, column=14).value = mname
                                            ws.cell(row=row, column=15).value = mstepDescription
                                            ws.cell(row=row, column=16).value = mexpectedResult
                                            row=row+1
                                    
            # file_name = f"TestSetId_{testSetId}.xlsx"
            wb.save("ConsolidatedTestSetReport.xlsx")
            messagebox.showinfo("Success", "Extracted all test cases")

    def extract_text_from_html(self,html):
        if html is not None:
            soup = BeautifulSoup(html, "html.parser")
            return soup.get_text()
        else:
            return ""

class Maintenance_Notification():
    def __init__(self):
        pass

    def no_digits(self,s):
        for x in "0123456789":
            s = s.replace(x, "")
        return s

    def checkdisplayname_email(self,name_email):
        try:
            OLApp = win32com.client.Dispatch("Outlook.Application")
            oRecip = OLApp.Session.CreateRecipient(name_email)
            oRecip.Resolve()

            if oRecip.Resolved:
                address_entry = oRecip.AddressEntry
                if address_entry.AddressEntryUserType in [0, 5]:  # olExchangeUserAddressEntry & olExchangeRemoteUserAddressEntry
                    oEU = address_entry.GetExchangeUser()
                    if oEU:
                        return oEU.PrimarySmtpAddress
                elif address_entry.AddressEntryUserType in [10, 30]:  # olOutlookContactAddressEntry & olSmtpAddressEntry
                    return address_entry.Address

        except Exception as e:
            print(f"Error in checkdisplayname_email: {e}")

        return None
        
    def process_users(self,tdc):
        print("Hi")
        userMails = ""
        # Write headers to the Excel sheet
        cust = tdc.Customization
        cust.Load()
        users = cust.Users.Users
        if tdc.Connected:
            print("Project name")

        for user in users:
            # print("hi")
            group_list = ""
            xtid = user.Name
            username = self.no_digits(user.FullName)
            # print(username)

            group_lists = user.GroupsList()

            # Iterate over the list of groups
            for group in group_lists:
                group_list += group.Name + ";"
            # print(group_list)
            
            email_address = self.checkdisplayname_email(xtid) 
            email_address2 =self.checkdisplayname_email(username)  # Use the new function
            if email_address:
                # userMails=email_address
                valid_invalid = "Valid"
                userMails += email_address + ";"
            elif email_address2:
                # userMails=email_address
                valid_invalid = "Valid"
                userMails += email_address2 + ";"
            else:
                # userMails=email_address
                valid_invalid = "Invalid"
                mail_id = ""
        return userMails

    def Outlook_attachment(self,all_mail_ids,from_date,to_date,from_hour,from_minute,from_am,to_hour,to_minute,to_am,reason,project_Name):
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)
        # mail_body="Mail_body"
        mail_body = f"Hi all,\n\nDue to {reason.strip()} the ALM services will not be available between {from_date} {from_hour}:{from_minute} {from_am} to {to_date} {to_hour}:{to_minute} {to_am}.\n\nRegards,\n Tools Admin Team"

        # print(from_date,to_date,from_hour,from_minute,to_hour,to_minute,reason)
        print(mail_body)

        # Additional email content
        # mail_body = "Hi Team,<br><br>Testing Mail<br><br>Regards,<br>Pongowtham"

        mail.Subject = f"ALM Maintenance Notification - {project_Name}"
        mail_body_html = mail_body.replace("\n", "<br>")
        mail.HTMLBody = f"<p>{mail_body_html}</p>"

        # Add each track name to Cc individually
        mail.To=all_mail_ids
        try:
            mail.Send()
            print("Email sent successfully.")
        except Exception as e:
            print(f"Error sending email: {e}")

class AccessProvider():
    def __init__(self):
        pass

    def Access_Provider(self,username,useremail,group,tdc):
        print("hi")
        try:
            # Check if user exists in ALM Site Admin
            user_exists_in_site = self.Check_if_user_is_in_siteadmin(tdc, username)
            
            if not user_exists_in_site:
                # If user does not exist in Site Admin, add them
                self.add_user_to_site_admin(tdc, username,useremail, group)
            time.sleep(2)
            userExists_Project = self.user_exists_in_project(tdc,username)
            if not userExists_Project:
                # print("have to add user to project")
                addition_Project=self.Add_user_to_project (tdc,username)
                time.sleep(2)
                if addition_Project:
                    print("User added to project")

                    cust = tdc.Customization
                    uList = cust.Users
                    # group_list = group.split(";")
                    flag=False
                    if group != "":
                        for user in uList.Users:
                            if user.Name.lower() == username.lower():
                                # Split group string into a list of groups
                                group_list = group.split(";")
                                for grp in group_list:
                                    userExists_Group=self.user_exists_in_group(tdc,username,grp)
                                    time.sleep(2)
                                    if not userExists_Group:
                                # Split group string into a list of groups
                                        user.AddToGroup(grp)
                                        flag = True
                                        cust.Commit()
                                        break  # Exit loop after adding user to groups
                    messagebox.showinfo("Success", "Access Granted")                        
                    return flag  
            else:
                cust = tdc.Customization
                uList = cust.Users
                # group_list = group.split(";")
                flag=False
                if group != "":
                    for user in uList.Users:
                        if user.Name.lower() == username.lower():
                            # Split group string into a list of groups
                            group_list = group.split(";")
                            for grp in group_list:
                                userExists_Group=self.user_exists_in_group(tdc,username,grp)
                                time.sleep(2)
                                if not userExists_Group:
                                    user.AddToGroup(grp)
                                    flag = True
                                    cust.Commit()
                                    break 
                    messagebox.showinfo("Success", "Access Granted") 
            return True

        except Exception as e:
            print(f"An error occurred: {e}")
            return False

        # finally:
        #     if tdc.Connected:
        #         tdc.Disconnect()        

    def user_exists_in_group(self,tdc,username,igroup):
        try:   
            cust = tdc.Customization
            uList = cust.Users
            userLists=uList.Users
            for user in userLists:
                if user.Name.lower() == username.lower():
                    GroupLists=user.GroupsList()
                    for group in GroupLists:
                        Name=group.Name
                        if Name is not None and Name.lower() == igroup.lower():
                            return True
 
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
                
    def Add_user_to_project (self,tdc,username):
        try:   
            cust = tdc.Customization
            uList = cust.Users
            list=uList.Users
            print(list)
            uList.AddUser (username)
            cust.Commit()
            # return True
            # sql_query=f"INSERT INTO USERS (US_USERNAME) VALUES ('{username}')"
            # command = tdc.Command
            # command.CommandText = sql_query
            # record_set = command.Execute()
            return True
        except Exception as e:
            print(f"An error occurred: {e}")
            return False

    def user_exists_in_project(self,tdc,username):
        try:   
            cust = tdc.Customization
            uList = cust.Users
            # user_lists=[]
            # sql_query=f"SELECT USERS.US_USERNAME FROM USERS"
            # command = tdc.Command
            # command.CommandText = sql_query
            # record_set = command.Execute()
            # while not record_set.EOR:  
            #     user_list = record_set.FieldValue(0)
            #     user_lists.append(user_list)
            #     record_set.next()


            # Initialize flag
            flag = False

            # Check if user exists in the project
            # for user in uList.Users:
            for user in uList.Users:
                if user.Name.lower() == username.lower():
                    flag = True
                    break  
            return flag

        except Exception as e:
            print(f"An error occurred: {e}")
            return False

    def Check_if_user_is_in_siteadmin(self,tdc, username):
            cust = tdc.Customization
            custUsers = cust.Users

            # Check if user exists in ALM Site Admin
            user_exists_in_siteadmin = custUsers.UserExistsInSite(username)
            
            if user_exists_in_siteadmin:
                print(username + " is present in SiteAdmin")
            else:
                print(username + " is absent in SiteAdmin")

            return user_exists_in_siteadmin
        

    def add_user_to_site_admin(self,tdc, username,useremail, group):
        try:    
            cust = tdc.Customization
            uList = cust.Users

            # Outlook configuration
            ol = win32com.client.Dispatch("Outlook.Application")
            ns = ol.GetNamespace("MAPI")
            new_mail = ol.CreateItem(0)
            new_mail.Subject = "Test Email"
            new_mail.To = useremail

            # Resolve recipient
            active_person_recipient = new_mail.Recipients.Item(1)
            if active_person_recipient.Resolve():
                OAE = new_mail.Recipients.Item(1).AddressEntry
                oExUser = OAE.GetExchangeUser()
                if oExUser.FirstName:
                    alias = username
                    full_name = f"{oExUser.FirstName} {oExUser.LastName}"
                    email = oExUser.PrimarySmtpAddress
                    phone_number = oExUser.BusinessTelephoneNumber
                    city = oExUser.City
                else:
                    alias, full_name, email, phone_number, city = "", "", "", "", ""
            else:
                alias, full_name, email, phone_number, city = username, "", "", "", ""

            # if full_name:
                # Add user to SiteAdmin
            uList.AddSiteUser(alias, full_name, email, city, phone_number," ")
            cust.Commit()
            print(f"User '{alias}' added successfully to ALM Site Admin.")
            return True
            # else:
            #     print("User does not exist in LDAP.")
            #     return False

        except Exception as e:
            print(f"An error occurred: {e}")
            return False

class ALMAdmin:

    def __init__(self, root):
        self.tdc = Dispatch("TDApiOle80.TDConnection")
        self.root = root
        self.root.title("One Stop ALM Administration")
        self.root.option_add("*tearOff", False)
        self.root.geometry("1380x720")
        # tdc2=self.tdc
        # self.root.resizable(True, False)

        # Set custom fonts and colors
        self.title_font = ("Berlin Sans FB Demi", 25, "bold")
        self.label_font2 = ("Calibri", 12)
        self.label_font = ("Calibri", 12, "bold")
        self.button_font = ("Arial", 12, "bold")
        self.bg_color = "#f2f2f2"
        self.fg_color = "#333333"
        self.tab_font = ("Calibri", 12)
        self.Olabel_font = ("Calibri", 8)

        # style
        self.style = ttk.Style(self.root)
        file_path = Path(__file__).with_name("forest-light.tcl")
        self.root.tk.call("source", file_path)
        self.style.theme_use("forest-light")
        self.style.configure("TNotebook.Tab", padding=[20, 0], font=self.tab_font)

        # self.background_image = Image.open("bg1.png")
        # self.background_photo = ImageTk.PhotoImage(self.background_image)
        bgimg = Path(__file__).with_name("bg2.png")
        self.bg = PhotoImage(file = bgimg) 

        self.login_page_widgets()

        self.user_id_entry = None
        self.user_id_label = None
        self.user_group_label=None
        self.user_group_dropdown = None
        self.add_button = None
        self.remove_button = None

    def open_calendar(self, event):
        # Method to open the calendar when the text box is clicked
        top = tk.Toplevel(self.root)
        cal = Calendar(top, selectmode="day")
        cal.pack()
        cal.bind("<<CalendarSelected>>", lambda event, entry=self.from_date_entry, top=top: self.populate_date(event, entry, top))

    def open_calendar_to_date(self, event):
        # Method to open the calendar when the text box is clicked
        top = tk.Toplevel(self.root)
        cal = Calendar(top, selectmode="day")
        cal.pack()
        cal.bind("<<CalendarSelected>>", lambda event, entry=self.to_date_entry, top=top: self.populate_date(event, entry, top))

    def populate_date(self, event, entry, top):
        # Method to populate the selected date in the entry widget and close the calendar
        selected_date = event.widget.get_date()
        entry.delete(0, tk.END)
        entry.insert(0, selected_date)
        top.destroy()

    def login_page_widgets(self):

        self.title_frame = ttk.Frame(self.root)
        self.title_frame.pack(expand=True, fill="both")

        Servers = [
            "https://ServerUrl/qcbin",
            "https://ServerUrl/qcbin"
            # Add more items as needed
        ]

        self.background_label = ttk.Label(self.title_frame, image=self.bg)
        self.background_label.grid(row=0, column=0, padx=(5, 25), pady=20)

        self.canvas1 = Frame( self.title_frame)
        self.canvas1.grid(row=0, column=1, sticky="ns", pady=220)

        self.connection_frame = ttk.Frame(self.canvas1)
        self.connection_frame.grid(row=0, column=0, padx=(5, 25), pady=20)
        
        # server label and entry
        server_label = ttk.Label(self.connection_frame, text="ALM Server: ",font=self.label_font)
        server_label.grid(row=0, column=0, padx=(5, 25), pady=10)
        # self.server_entry = ttk.Entry(self.connection_frame)
        # self.server_entry.grid(row=0, column=1, padx=(5, 25), pady=10)

        self.server_entry = ttk.Combobox(self.connection_frame, values=Servers, state="readonly", width=20)
        self.server_entry.current(0)
        self.server_entry.grid(row=0, column=1, padx=(5, 25), pady=10)


        # username label and entry
        username_label = ttk.Label(self.connection_frame, text="Username: ",font=self.label_font)
        username_label.grid(row=1, column=0, padx=(5, 25), pady=10)
        self.username_entry = ttk.Entry(self.connection_frame)
        self.username_entry.grid(row=1, column=1, padx=(5, 25), pady=10)

        # password label and entry
        password_label = ttk.Label(self.connection_frame, text="Password: ",font=self.label_font)
        password_label.grid(row=2, column=0, padx=(5, 25), pady=10)
        self.password_entry = ttk.Entry(self.connection_frame, show="*")
        self.password_entry.grid(row=2, column=1, padx=(5, 25), pady=10)

        # connect button
        connect_button = ttk.Button(self.canvas1, text="Login",style="Accent.TButton", command=self.connect)
        connect_button.grid(row=1, column=0, padx=25, pady=10)
    
    def get_visible_domains(self):
    # Use appropriate method to fetch visible domains dynamically
    # Example:
    # visible_domains = fetch_visible_domains_from_api()
        visible_domains = self.tdc.VisibleDomains
        return visible_domains
    
    def connect_to_alm(self):
        # Connect to the selected domain and project
        selected_domain = self.domain_dropdown.get()
        selected_project = self.project_dropdown.get()
        try:
            self.tdc.Connect(selected_domain,selected_project)
            messagebox.showinfo("Success", "Connected to : "+ selected_project)                  
        # Perform connection logic here, replace with actual implementation
        # For demonstration, let's print the selected domain and project
        except Exception as e:
            messagebox.showerror("Connect Error", f"Connection to ALM failed: {str(e)}")
    

    def get_projects_for_domain(self, domain):
            # Placeholder list of projects for the selected domain (replace with actual implementation)
            domain_projects = self.tdc.VisibleProjects(domain)
            project_list = []
            for project in domain_projects:
                # print(project)
                project_list.append(project)
            return project_list

    def update_projects(self):
        selected_domain = self.domain_dropdown.get()
        if selected_domain:
            # Fetch projects for the selected domain (replace with actual implementation)
            domain_projects = self.get_projects_for_domain(selected_domain)
            # Clear previous values and set new values
            if domain_projects:
                self.project_dropdown['values'] = domain_projects
                self.project_dropdown.current(0)
            else:
                # Clear project dropdown if no projects are available
                self.project_dropdown['values'] = ()

    
    def Generate_Evidence(self):
        # Call the ALMQueryProcessor to execute the query and save to Excel
        alm_query_processor = ALMQueryProcessor()
        excel_path = self.Excel_entry.get()
        print("Excel Path:", excel_path)
        excel_file = "ALM_Query_Results.xlsx"
        word_file_prefix = "ALM_Query_Results"
        alm_query_processor.execute_query_and_save_to_excel(excel_path, excel_file, word_file_prefix,self.tdc)

        # Your remaining code in Generate_Evidence method


    def Test_Evidence_Generator(self):
        print("Hi")
        Evidence_frame = ttk.Frame(self.tab3_frame)
        Evidence_frame.grid(row=1, column=0, padx=(5, 25), pady=(10, 20))

        Evidence_label = ttk.Label(Evidence_frame, text="Input Excel File: ", font=self.label_font)
        Evidence_label.grid(row=0, column=0, padx=5, pady=5)
        self.Excel_entry = ttk.Entry(Evidence_frame)
        self.Excel_entry.grid(row=0, column=1, padx=5, pady=5)

        # Create Remove button
        self.generate_button = ttk.Button(Evidence_frame, text="Generate", command=self.Generate_Evidence)
        self.generate_button.grid(row=1, column=0, columnspan=2, pady=(10, 0)) 

    def TestType_Update(self):
        test_type_updator = TestTypeUpdator()
        test_case_ids = self.Update_entry.get().split(",") 
        print(test_case_ids)
        manual_process_value = self.test_type_var.get()
        print(manual_process_value)
        test_type_updator.execute_conversion(test_case_ids, manual_process_value,self.tdc)

    
    def Test_Type_Update(self):
        print("Hi")
        Update_frame = ttk.Frame(self.tab4_frame)
        Update_frame.grid(row=1, column=0, padx=(5, 25), pady=(10, 20))

        Update_label = ttk.Label(Update_frame, text="Test case ID's (comma-separated): ", font=self.label_font)
        Update_label.grid(row=0, column=0, padx=5, pady=5)
        self.Update_entry = ttk.Entry(Update_frame)
        self.Update_entry.grid(row=0, column=1, padx=5, pady=5)

        # Dropdown for manual/process selection
        Test_type_label = ttk.Label(Update_frame, text="Select any test Type: ", font=self.label_font)
        Test_type_label.grid(row=1, column=0, padx=5, pady=5)  

        self.test_type_var = tk.StringVar()
        test_type_combo = ttk.Combobox(Update_frame, textvariable=self.test_type_var)
        test_type_combo['values'] = ('QUICKTEST_TEST', 'BUSINESS-PROCESS','MANUAL','FLOW','VAPI-XP-TEST','SYSTEM-TEST','QAINSPECT-TEST','PERFORMANCE-TEST','LR-SCENARIO','LEANFT-TEST','ALT-SCENARIO')
        test_type_combo.current(0)  # Set the default value
        test_type_combo.grid(row=1, column=1, padx=5, pady=5)

        # Create Remove button
        self.Update_button = ttk.Button(Update_frame, text="Update", command=self.TestType_Update)
        self.Update_button.grid(row=2, column=1, columnspan=2, pady=(10, 0))

    def Defect_Get_Values(self):
        defect_extractor = DefectExtractor()
        status_input = self.Status_entry.get()
        priority_input = self.Priority_entry.get()
        severity_input = self.Severity_entry.get()
        category_input=self.Category_entry.get()

        # Split the status input by commas and create a list of status values
        status_list = [status.strip() for status in status_input.split(",") if status]
        priority_list = [priority.strip() for priority in priority_input.split(",") if priority]
        severity_list = [severity.strip() for severity in severity_input.split(",") if severity]
        category_list = [category.strip() for category in category_input.split(",") if category]

        # Call Defect_Extraction function with the provided values
        defect_extractor.Defect_Extraction(status_list, priority_list, severity_list,category_list,self.tdc)        

    
    def Defect_Extractor(self):
        print("Hi")
        Defect_frame = ttk.Frame(self.tab5_frame)
        Defect_frame.grid(row=1, column=0, padx=(5, 25), pady=(10, 20)) 
        
        Status_label = ttk.Label(Defect_frame, text="Status (comma-separated) :", font=self.label_font)
        Status_label.grid(row=0, column=0, padx=5, pady=5)
        self.Status_entry = ttk.Entry(Defect_frame)
        self.Status_entry.grid(row=0, column=1, padx=5, pady=5)

        Priority_label = ttk.Label(Defect_frame, text="Priority (comma-separated) :", font=self.label_font)
        Priority_label.grid(row=1, column=0, padx=5, pady=5)
        self.Priority_entry = ttk.Entry(Defect_frame)
        self.Priority_entry.grid(row=1, column=1, padx=5, pady=5)                

        Severity_label = ttk.Label(Defect_frame, text="Severity (comma-separated) :", font=self.label_font)
        Severity_label.grid(row=2, column=0, padx=5, pady=5)
        self.Severity_entry = ttk.Entry(Defect_frame)
        self.Severity_entry.grid(row=2, column=1, padx=5, pady=5) 

        Category_label = ttk.Label(Defect_frame, text="Defect Category (comma-separated) :", font=self.label_font)
        Category_label.grid(row=3, column=0, padx=5, pady=5)
        self.Category_entry = ttk.Entry(Defect_frame)
        self.Category_entry.grid(row=3, column=1, padx=5, pady=5) 

                # Create Remove button
        self.Extract_button = ttk.Button(Defect_frame, text="Extract", command=self.Defect_Get_Values)
        self.Extract_button.grid(row=4, column=1, columnspan=2, pady=(10, 0))

     
    def test_extraction_fields(self):
        TC_frame = ttk.Frame(self.tab2_frame)
        TC_frame.grid(row=1, column=0, padx=(5, 25), pady=(10, 20)) 
        
        self.radio_var = tk.IntVar()
        self.radio_var.trace("w", self.show_hide_elements)  # Add trace to the variable

        self.radio_manual = ttk.Radiobutton(TC_frame, text="From Test Plan", variable=self.radio_var, value=1)
        self.radio_manual.grid(row=0, column=0, padx=5, pady=5)

        self.radio_process = ttk.Radiobutton(TC_frame, text="From Test Set", variable=self.radio_var, value=2)
        self.radio_process.grid(row=0, column=1, padx=5, pady=5)

        self.radio_Attachment = ttk.Radiobutton(TC_frame, text="Attachment Extraction", variable=self.radio_var, value=3)
        self.radio_Attachment.grid(row=0, column=2, padx=5, pady=5)

        # Additional elements
        self.folder_path_label = ttk.Label(TC_frame, text="Folder Path: ", font=self.label_font)
        self.folder_path_entry = ttk.Entry(TC_frame)
        self.attachments_var = tk.BooleanVar()
        self.attachments_check = ttk.Checkbutton(TC_frame, text="With Attachments", variable=self.attachments_var)
        # Extract button
        self.extract_button = ttk.Button(TC_frame, text="Extract", command=self.extract_with_or_without_attachments)
        self.extract_button.grid(row=4, column=0, columnspan=2, pady=(10, 0))
        self.extract_button.grid_forget()

        # Test Set related elements (initially hidden)
        self.test_set_ids_label = ttk.Label(TC_frame, text="Enter Test Set IDs: ", font=self.label_font)
        self.test_set_ids_entry = ttk.Entry(TC_frame)
        self.extract_test_cases_button = ttk.Button(TC_frame, text="Extract Test Cases", command=self.extract_test_cases_TS)
        
        # Additional elements for attachments
        self.Attachment_label = ttk.Label(TC_frame, text="Test set Id's: ", font=self.label_font)
        self.Attachment_entry = ttk.Entry(TC_frame)

        # Extract button- Attachments
        self.Att_extract_button = ttk.Button(TC_frame, text="Extract", command=self.extract_Attachment)
        # self.Att_extract_button.grid(row=4, column=0, columnspan=2, pady=(10, 0))
        # self.Att_extract_button.grid_forget()
        self.Att_all_extract_button = ttk.Button(TC_frame, text="Extract All", command=self.extract_Attachment_All)
        # self.Att_all_extract_button.grid(row=4, column=1, columnspan=2, pady=(10, 0))
        # self.Att_all_extract_button.grid_forget()        
        
        # Hide Test Set related elements initially
        self.test_set_ids_label.grid_forget()
        self.test_set_ids_entry.grid_forget()
        self.extract_test_cases_button.grid_forget()

    def show_hide_elements(self, *args):
        radio_value = self.radio_var.get()
        if radio_value == 1:  # From Test Plan selected
            self.folder_path_label.grid(row=1, column=0, padx=5, pady=5, sticky="e")
            self.folder_path_entry.grid(row=1, column=1, padx=5, pady=5)
            self.attachments_check.grid(row=2, column=0, columnspan=2, padx=5, pady=5)
            self.extract_button.grid(row=4, column=0, columnspan=2, pady=(10, 0))
            # Hide Test Set related elements
            self.test_set_ids_label.grid_forget()
            self.test_set_ids_entry.grid_forget()
            self.extract_test_cases_button.grid_forget()
            self.Attachment_label.grid_forget()
            self.Attachment_entry.grid_forget()
            self.Att_extract_button.grid_forget()
            self.Att_all_extract_button.grid_forget()

        elif radio_value == 2:  # From Test Set selected
            # Hide elements related to Test Plan
            self.folder_path_label.grid_forget()
            self.folder_path_entry.grid_forget()
            self.attachments_check.grid_forget()
            self.extract_button.grid_forget()
            self.Attachment_label.grid_forget()
            self.Attachment_entry.grid_forget()
            self.Att_extract_button.grid_forget()
            self.Att_all_extract_button.grid_forget()
            
            # Show Test Set related elements
            self.test_set_ids_label.grid(row=1, column=0, padx=5, pady=5, sticky="e")
            self.test_set_ids_entry.grid(row=1, column=1, padx=5, pady=5)
            self.extract_test_cases_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)
        elif radio_value == 3:
            self.test_set_ids_label.grid_forget()
            self.test_set_ids_entry.grid_forget()
            self.extract_test_cases_button.grid_forget()
            self.folder_path_label.grid_forget()
            self.folder_path_entry.grid_forget()
            self.attachments_check.grid_forget()
            self.extract_button.grid_forget()  

            self.Attachment_label.grid(row=1, column=0, padx=5, pady=5, sticky="e")
            self.Attachment_entry.grid(row=1, column=1, padx=5, pady=5)
            self.Att_extract_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)
            self.Att_all_extract_button.grid(row=2, column=1, columnspan=2, padx=5, pady=5)




    def extract_test_cases_TS(self):
        # print("hi test set")
        test_set_ids=self.test_set_ids_entry.get()
        test_case_extractor3 = testCaseExtractor_TS()
        test_case_extractor3.download_test_cases(test_set_ids,self.tdc)
        # ids_list = test_set_ids.split(',')
        # for test_set_id in ids_list:
        #     print(test_set_id)

    def extract_Attachment(self):
        testsetids=self.Attachment_entry.get()
        print(f"Downloading attachment for the test set {testsetids}")
        Attachment_Extractor = Attachment_Downloader()
        Attachment_Extractor.download_Attachments(testsetids,self.tdc)

    def extract_Attachment_All(self):
        print("Downloading attachments in the entire test set")
        Attachment_Extractor = Attachment_Downloader()
        Attachment_Extractor.download_Attachments_All(self.tdc)

    def extract_with_or_without_attachments(self):
        if self.attachments_var.get():
            self.extract_with_attachments()
        else:
            self.extract_without_attachments()

    def extract_with_attachments(self):
        print("Extracting test cases with Attachment...")
        test_case_extractor = testCaseExtractor_WA()
        folder_path=self.folder_path_entry.get()
        test_case_extractor.TestCase_WA(folder_path,self.tdc)
        pass

    def extract_without_attachments(self):
        print("Extracting test cases without Attachment...")
        test_case_extractor2 = testCaseExtractor()
        folder_path=self.folder_path_entry.get()
        test_case_extractor2.TestCase_WA(folder_path,self.tdc)
        pass   

    def SendNotification(self):
        print("Hi")
        from_date = self.from_date_entry.get()
        to_date = self.to_date_entry.get()
        from_hour = self.from_hour_combobox.get()
        from_minute = self.from_minute_combobox.get()
        from_am = self.from_am_pm_combobox.get()
        to_hour = self.to_hour_combobox.get()
        to_minute = self.to_minute_combobox.get()
        to_am = self.from_am_pm_combobox.get()
        # reason=self.additional_entry.get()
        reason = self.additional_entry.get("1.0", "end")
        # print(from_date,to_date,from_hour,from_minute,to_hour,to_minute,reason)
        notificationSender = Maintenance_Notification()
        mailUsers = notificationSender.process_users(self.tdc)
        # print(mailUsers)
        if self.tdc.Connected:
            project_Name=self.tdc.ProjectName
        notificationSender.Outlook_attachment(mailUsers,from_date,to_date,from_hour,from_minute,from_am,to_hour,to_minute,to_am,reason,project_Name)


    def Maintenance_Notification(self):
        print("Hi")
        Maintenance_frame = ttk.Frame(self.tab6_frame)
        Maintenance_frame.grid(row=1, column=0, padx=(5, 25), pady=(10, 20)) 
        
        Fdate_label = ttk.Label(Maintenance_frame, text="Maintenance From Date:", font=self.label_font)
        Fdate_label.grid(row=0, column=0, padx=5, pady=5)
        # self.Fdate_entry = ttk.Entry(Maintenance_frame)
        # self.Fdate_entry.grid(row=0, column=1, padx=5, pady=5)
        # self.cal = Calendar(Maintenance_frame, selectmode="day", year=2024, month=4, day=22)
        # self.cal.grid(row=0, column=1, padx=5, pady=5)

        # Entry widget for displaying the selected date
        self.from_date_entry = ttk.Entry(Maintenance_frame)
        self.from_date_entry.grid(row=0, column=1, padx=5, pady=5)

        # Bind click event to open the calendar
        self.from_date_entry.bind("<Button-1>",self.open_calendar)

        Tdate_label = ttk.Label(Maintenance_frame, text="Maintenance To Date:", font=self.label_font)
        Tdate_label.grid(row=1, column=0, padx=5, pady=5)
        # self.Tdate_entry = ttk.Entry(Maintenance_frame)
        # self.Tdate_entry.grid(row=1, column=1, padx=5, pady=5)      

        self.to_date_entry = ttk.Entry(Maintenance_frame)
        self.to_date_entry.grid(row=1, column=1, padx=5, pady=5)

        # Bind click event to open the calendar
        self.to_date_entry.bind("<Button-1>",self.open_calendar_to_date)          

        Ftime_label = ttk.Label(Maintenance_frame, text="Maintenance From Time:", font=self.label_font)
        Ftime_label.grid(row=2, column=0, padx=5, pady=5)
        # self.Ftime_entry = ttk.Entry(Maintenance_frame)
        # self.Ftime_entry.grid(row=2, column=1, padx=5, pady=5) 

        # Hour selection
        self.from_hour_combobox = ttk.Combobox(Maintenance_frame, values=[str(i).zfill(2) for i in range(24)], state="readonly", width=3)
        self.from_hour_combobox.current(0)
        self.from_hour_combobox.grid(row=2, column=1, padx=5, pady=5)

        # Minute selection
        self.from_minute_combobox = ttk.Combobox(Maintenance_frame, values=[str(i).zfill(2) for i in range(60)], state="readonly", width=3)
        self.from_minute_combobox.current(0)
        self.from_minute_combobox.grid(row=2, column=2, padx=5, pady=5)

        #AM_PM
        self.from_am_pm_combobox = ttk.Combobox(Maintenance_frame, values=["AM", "PM"], state="readonly", width=3)
        self.from_am_pm_combobox.current(0)
        self.from_am_pm_combobox.grid(row=2, column=3, padx=5, pady=5)

        Ttime_label = ttk.Label(Maintenance_frame, text="Maintenance To Time:", font=self.label_font)
        Ttime_label.grid(row=3, column=0, padx=5, pady=5)
        # self.Ttime_entry = ttk.Entry(Maintenance_frame)
        # self.Ttime_entry.grid(row=3, column=1, padx=5, pady=5) 

        # Hour selection
        self.to_hour_combobox = ttk.Combobox(Maintenance_frame, values=[str(i).zfill(2) for i in range(24)], state="readonly", width=3)
        self.to_hour_combobox.current(0)
        self.to_hour_combobox.grid(row=3, column=1, padx=5, pady=5)

        # Minute selection
        self.to_minute_combobox = ttk.Combobox(Maintenance_frame, values=[str(i).zfill(2) for i in range(60)], state="readonly", width=3)
        self.to_minute_combobox.current(0)
        self.to_minute_combobox.grid(row=3, column=2, padx=5, pady=5)

        #AM_PM
        self.to_am_pm_combobox = ttk.Combobox(Maintenance_frame, values=["AM", "PM"], state="readonly", width=3)
        self.to_am_pm_combobox.current(0)
        self.to_am_pm_combobox.grid(row=3, column=3, padx=5, pady=5)

        # Create a label for the additional text area
        additional_label = ttk.Label(Maintenance_frame, text="Reason for Maintenance:", font=self.label_font)
        additional_label.grid(row=4, column=0, padx=5, pady=5)
        self.additional_entry = tk.Text(Maintenance_frame, width=40, height=5)
        self.additional_entry.grid(row=4, column=1, padx=5, pady=5)

        # Create Remove button
        self.Extract_button = ttk.Button(Maintenance_frame, text="Send Notification", command=self.SendNotification)
        self.Extract_button.grid(row=7, column=1, columnspan=2, pady=(10, 0))

        # self.send_notification_button = ttk.Button(Maintenance_frame, text="Send Notification", command=self.SendNotification)
        # self.send_notification_button.grid(row=7, column=1, columnspan=2, pady=(10, 0))

    def access_management_fields(self):
        print("Access management welcomes you")
        Access_frame = ttk.Frame(self.tab1_frame)
        Access_frame.grid(row=1, column=0, padx=(5, 25), pady=(10, 20))
        if self.tdc.connected:
        #project group values
                qc_connection=self.tdc
                sql_query = f"SELECT GROUPS.GR_GROUP_NAME FROM GROUPS"
                command = qc_connection.Command
                command.CommandText = sql_query
                record_set = command.Execute()
                group_Names=[]
                while not record_set.EOR:
                    Group_Name = record_set.FieldValue(0)
                    print(Group_Name)
                    group_Names.append(Group_Name)
                    record_set.next()
                print(group_Names) 
        # User ID entry
        user_id_label = ttk.Label(Access_frame, text="User ID:", font=self.label_font)
        user_id_label.grid(row=0, column=0, padx=5, pady=5)
        self.user_id_entry = ttk.Entry(Access_frame)
        self.user_id_entry.grid(row=0, column=1, padx=5, pady=5)

        # User email entry
        user_email_label = ttk.Label(Access_frame, text="User Email:", font=self.label_font)
        user_email_label.grid(row=1, column=0, padx=5, pady=5)
        self.user_email_entry = ttk.Entry(Access_frame)
        self.user_email_entry.grid(row=1, column=1, padx=5, pady=5)

        # Dropdown for group selection
        group_label = ttk.Label(Access_frame, text="Group:", font=self.label_font)
        group_label.grid(row=2, column=0, padx=5, pady=5)
        self.group_var = tk.StringVar()
        self.group_combobox = ttk.Combobox(Access_frame, textvariable=self.group_var)
        self.group_combobox['values'] = group_Names
        if group_Names:
            self.group_combobox.current(0)  # Set the default value if there are values
        self.group_combobox.grid(row=2, column=1, padx=5, pady=5)
        # group_combobox.current(0)  # Set the default value
        # group_combobox.grid(row=2, column=1, padx=5, pady=5)

        # Create Grant Access button
        grant_access_button = ttk.Button(Access_frame, text="Grant Access", command=self.grant_access)
        grant_access_button.grid(row=3, column=0, columnspan=2, pady=(10, 0))

    def grant_access(self):
        print("Granted access")
        access_provider=AccessProvider()
        username=self.user_id_entry.get()
        useremail=self.user_email_entry.get()
        group=self.group_combobox.get()
        access_provider.Access_Provider(username,useremail,group,self.tdc)


    def on_tab_change(self, event):
        # Callback function for tab change event
        current_tab = event.widget.tab(event.widget.select(), "text")


        if current_tab=="User Access Management":
            self.clear_tab(self.tab1_frame)
            self.access_management_fields() 
        if current_tab == "  Data Extraction  ":
            self.clear_tab(self.tab2_frame)
            self.test_extraction_fields() 
        elif current_tab == " Test Evidence Generator ":
            self.clear_tab(self.tab3_frame)
            self.Test_Evidence_Generator()
        elif current_tab == "Test Type Update":
            self.clear_tab(self.tab4_frame)
            self.Test_Type_Update()
        elif current_tab == "Defect Extractor":
            self.clear_tab(self.tab5_frame)
            self.Defect_Extractor()
        elif current_tab == "Maintenance Notification":
            self.clear_tab(self.tab6_frame)
            self.Maintenance_Notification()

    def clear_tab(self, frame):
        # Clear all widgets in the given frame
        for widget in frame.winfo_children():
            widget.destroy()
            
    def landing_page_widgets(self, server, username, password):

        # bgfooter = Path(__file__).with_name("FooterNew.png")
        # footer_photo = PhotoImage(file = bgfooter) 

        # # Create a label to display the image
        # footer_label = tk.Label(root, image=footer_photo)
        # footer_label.image = footer_photo  # Keep a reference to avoid garbage collection
        # footer_label.grid(row=2, column=0, columnspan=2, pady=5)  # Adjust row and column as needed


        self.landing_page = ttk.Frame(root)
        self.landing_page.grid(row=0, column=0, sticky="nsew")

        # Title label
        self.title_label = ttk.Label(self.landing_page, text="One Stop ALM Administration", font=self.title_font)
        self.title_label.pack(padx=(10, 25), pady=20, side="left")

        self.c_frame = ttk.Frame(self.landing_page)
        self.c_frame.pack(side="right", padx=(100, 2), pady=20)

        # Domain and project connection
        self.domain_label = ttk.Label(self.c_frame, text="Domain:", font=self.label_font)
        self.domain_label.pack(side="left", pady=10, padx=(10, 1))

        try:
            # print("Server:", server)
            # print("Username:", username)
            # print("Password:", password)
            self.tdc.InitConnectionEx(server)
            self.tdc.Login(username, password)
        except Exception as e:
            messagebox.showerror("Login Error", f"Login to ALM failed: {str(e)}")

        # Fetch visible domains and convert to list
        visible_domains = self.get_visible_domains()
        # print(visible_domains)
        dom_list = []
        for domain in visible_domains:
            # print (domain)
            dom_list.append(domain)

        self.domain_dropdown = ttk.Combobox(self.c_frame, state="readonly", values=dom_list,
                                            font=self.Olabel_font, width=20, height=5)

        self.domain_dropdown.current(0)
        self.domain_dropdown.pack(side="right", pady=10, padx=(1, 10))
        self.domain_dropdown.bind("<<ComboboxSelected>>", lambda event: self.update_projects())

        self.project_label = ttk.Label(self.c_frame, text="Project:", font=self.label_font)
        self.project_label.pack(side="right", pady=10, padx=(10, 1), before=self.domain_dropdown)

        self.project_dropdown = ttk.Combobox(self.c_frame, state="readonly",
                                            font=self.Olabel_font, width=20, height=5)
        self.project_dropdown.pack(side="right", pady=10, padx=(1, 10), before=self.project_label)

        # Connect button
        self.connect_button = ttk.Button(self.c_frame, text="Connect", style="Accent.TButton", command=self.connect_to_alm)
        self.connect_button.pack(side="right", padx=(20, 1), pady=10, before=self.project_dropdown)

        self.tab_control = ttk.Notebook(self.root)
        self.tab_control.grid(row=1, column=0, columnspan=2, sticky="nsew")

        # tabs
        self.tab1 = ttk.Frame(self.tab_control)
        self.tab2 = ttk.Frame(self.tab_control)
        self.tab3 = ttk.Frame(self.tab_control)
        self.tab4 = ttk.Frame(self.tab_control)
        self.tab5 = ttk.Frame(self.tab_control)
        self.tab6 = ttk.Frame(self.tab_control)

        self.tab_control.add(self.tab1, text="User Access Management")
        self.tab_control.add(self.tab2, text="  Data Extraction  ")
        self.tab_control.add(self.tab3, text=" Test Evidence Generator ")
        self.tab_control.add(self.tab4, text="Test Type Update")
        self.tab_control.add(self.tab5, text="Defect Extractor")
        self.tab_control.add(self.tab6, text="Maintenance Notification")

        # contents to each tab
        self.tab1_frame = ttk.Frame(self.tab1)
        self.tab1_frame.pack()

        self.tab2_frame=ttk.Frame(self.tab2)
        self.tab2_frame.pack()

        self.tab3_frame=ttk.Frame(self.tab3)
        self.tab3_frame.pack()

        self.tab4_frame=ttk.Frame(self.tab4)
        self.tab4_frame.pack()

        self.tab5_frame=ttk.Frame(self.tab5)
        self.tab5_frame.pack()

        self.tab6_frame=ttk.Frame(self.tab6)
        self.tab6_frame.pack()

        self.tab_control.select(1) 

        self.tab_control.bind("<<NotebookTabChanged>>", self.on_tab_change)

        # weights for responsive layout
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_columnconfigure(2, weight=1)
        self.tab_control.grid_rowconfigure(0, weight=1)

    def connect(self):

        server = self.server_entry.get()
        username = self.username_entry.get()
        password = self.password_entry.get()
        self.title_frame.destroy()
        self.landing_page_widgets(server,username,password)
        # self.root.destroy()
        # root = tk.Tk()
        # app = ALMAdminApp(root)

    def run(self):
        #main event loop
        self.root.mainloop()

if __name__ == "__main__":
    root = tk.Tk()
    app = ALMAdmin(root)
    root.mainloop()
    app.run()